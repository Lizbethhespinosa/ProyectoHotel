/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;

/**
 *
 * @author Josem
 */
public class Jugadores extends Persona {
    private String equipo;

    public Jugadores() {
    }

    @Override
    public void darDatos() {
        this.nombre = leer.leerString("Ingrese el nombre del jugador");
        this.celular = leer.leerString("Ingrese su número de celular");
        this.equipo = leer.leerString("Ingrese su equipo: ");
        this.ID = leer.leeryValidarInt("Ingrese su ID");
        System.out.println("Se le asignó la habitación: A"); 
        System.out.println("No se preocupe por los gastos, las directivas de " + this.equipo + " se encargarán de todo.");
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }
}