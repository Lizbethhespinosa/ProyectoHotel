/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hotelfinal2;

/**
 *
 * @author Josem
 */

public class HotelFinal2 {  
    static FacturarHabitacion facturar = new FacturarHabitacion();
    static Lavanderia lavar = new Lavanderia();
    static Daños daños = new Daños();
    static Robos robos = new Robos();
    static Lectura leer = new Lectura();
    
    public static void mostrarFactura() {
        Persona persona = null;

        System.out.println("¿Es usted jugador de fútbol o huésped?");
        System.out.println("1) Jugador de fútbol");
        System.out.println("2) Huésped");
        int opcion = leer.leeryValidarInt2("Ingrese una opción: ", 1, 2);

        if (opcion == 1) {
            persona = new Jugadores();
            persona.darDatos();
            System.out.println(persona.getNombre() + ", no se preocupe por los gastos, las directivas de " + ((Jugadores) persona).getEquipo() + " se encargarán de todo.");
        } else if (opcion == 2) {
            persona = new Huesped();
            persona.darDatos();
        } else {
            System.out.println("Opción inválida. Intente de nuevo.");
            return;
        }

        if (persona instanceof Jugadores) {
            return;
        }

        facturar.seleccionarTipo(persona);
        lavar.calculoLavanderia();
        daños.registrarIncidentes();
        robos.registrarRobos();

        int total = facturar.getPreciofinal() + lavar.getTotalLavanderia() + (int) daños.calcularCostoTotalIncidentes() + (int) robos.calcularCostoTotalRobos();

        String nombreUsuario = persona.getNombre();
        int idUsuario = persona.getID();

        System.out.println("Usuario: " + nombreUsuario);
        System.out.println("Identificado con el número: " + idUsuario);
        System.out.println("El total de su factura en el hotel está estimada por un precio de: " + total);
    }
    
    public static void main(String[] args) {
       mostrarFactura();
    }
}
