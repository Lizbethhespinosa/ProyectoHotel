/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;

/**
 *
 * @author Josem
 */
public class Lavanderia {
    
    private Lectura leer = new Lectura();
    private int preguntar;
    private final int precioServicio = 50000;
    private int numLavadas;
    private int totalLavanderia;

    public Lavanderia() {
    }

    public Lavanderia(int preguntar, int numLavadas, int totalLavanderia) {
        this.preguntar = preguntar;
        this.numLavadas = numLavadas;
        this.totalLavanderia = totalLavanderia;
    }

    
    
    public void calculoLavanderia(){
        int lavanderia = leer.leeryValidarInt("Ingrese: (1) si lavó, (0) si no lavó");
        if (lavanderia == 1){
            this.numLavadas = leer.leeryValidarInt("ingrese el numero de veces que lavó ");
            this.totalLavanderia = this.precioServicio * this.numLavadas;
            System.out.println("El costo total de lavandería es de "  + totalLavanderia );
            
            
        }
    }

    public Lectura getLeer() {
        return leer;
    }

    public void setLeer(Lectura leer) {
        this.leer = leer;
    }

    public int getPreguntar() {
        return preguntar;
    }

    public void setPreguntar(int preguntar) {
        this.preguntar = preguntar;
    }

    public int getNumLavadas() {
        return numLavadas;
    }

    public void setNumLavadas(int numLavadas) {
        this.numLavadas = numLavadas;
    }

    public int getTotalLavanderia() {
        return totalLavanderia;
    }

    public void setTotalLavanderia(int totalLavanderia) {
        this.totalLavanderia = totalLavanderia;
    }
    
}
