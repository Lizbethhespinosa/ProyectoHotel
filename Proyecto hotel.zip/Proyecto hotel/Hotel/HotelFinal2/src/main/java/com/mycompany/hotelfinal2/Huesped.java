/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;
import java.util.ArrayList;
/**
 *
 * @author Josem
 */
public class Huesped extends Persona {
    
    public Huesped() {
    }
    
    public void darDatos() {
        this.nombre = leer.leerString("Ingrese el nombre del huésped");
        this.celular = leer.leerString("Ingrese su número de celular");
        this.ID = leer.leeryValidarInt("Ingrese su ID");
    }
}

 

