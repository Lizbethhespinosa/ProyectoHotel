/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;

import java.util.ArrayList;

/**
 *
 * @author Josem
 */
public class HabitacionD implements Habitacion{ //d porque es mi hotel y en mi hotel no hay c profe, asi de sencillo
    private String numero;
    private final int precioD = 500000;
    private int noches;
    private int costo;
        private boolean ocupada = false;


    ArrayList<String> habitaciones = new ArrayList<>();   
    Lectura leer = new Lectura();
    Huesped persona = new Huesped();

     public boolean isOcupada() {
        return ocupada;
    }
    
    public int getNoches() {
        return noches;
    }

    public void setNoches(int noches) {
        this.noches = noches;
    }

    
    /**
     * @return the numero   
     */
    public String getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getPrecioD() {
        return precioD;
    }
    
        public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

        public boolean estaOcupada() {
    return this.ocupada;
}

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }

    
    @Override
 
    public void datos_habitacion() {
       
        for (int i = 1; i <= 10; i++) {
    habitaciones.add("d" + i);
}

// To print the room numbers:
        for (String habitacion : habitaciones) {
            System.out.println(habitacion);
        }
        this.numero = leer.leerString("Ingrese el numero de habitacion que va a facturar ");
        this.noches= leer.leeryValidarInt("Ingrese el numero de noches");
        this.setOcupada(true);
    }
    public int calcularCostoD(){
        this.costo = this.noches * this.precioD;
        System.out.println("El valor a pagar de la habitacion: "+this.numero+ " es de" + this.costo);
        return this.costo;
    }
    
    
    
}
