    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Josem
 */
package com.mycompany.hotelfinal2;

import java.util.ArrayList;
import java.util.List;

public class Robos {
    private List<Robo> robosRegistrados;
    private Lectura lectura = new Lectura();

    public Robos() {
        this.robosRegistrados = new ArrayList<>();
    }

    public void registrarRobos() {
        int tipoRobo;
        int calcularMas = 1;
        do {
            tipoRobo = lectura.leeryValidarInt2("Ingrese el tipo de robo (1 para robo menor, 2 para robo moderado, 3 para robo mayor, 4 si no hubo robos): ", 1, 4);
            double costoRobo = 0;
            switch (tipoRobo) {
                case 1:
                    costoRobo = 50000; // Robo menor
                    break;
                case 2:
                    costoRobo = 100000; // Robo moderado
                    break;
                case 3:
                    costoRobo = 200000; // Robo mayor
                    break;
                case 4:
                    System.out.println("No se registraron robos.");
                    break;
                default:
                    break;
            }

            if (tipoRobo >= 1 && tipoRobo <= 3) {
                agregarRobo(tipoRobo, costoRobo);
                System.out.println("Robo registrado con éxito.");
            }

            // Verifica si el usuario quiere registrar más robos solo si no ha elegido la opción "no hubo robos"
            if (tipoRobo != 4) {
                calcularMas = lectura.leeryValidarInt2("¿Desea registrar otro robo? (0) para No, (1) para Sí): ", 0, 1);
            } else {
                calcularMas = 0; // No preguntar de nuevo si elige la opción de no hubo robos
            }
        } while (calcularMas == 1);

        // Mostrar el costo total de los robos registrados
        mostrarTotalRobos();
    }

    public void agregarRobo(int tipo, double costo) {
        Robo robo = new Robo(tipo, costo);
        robosRegistrados.add(robo);
    }

    public double calcularCostoTotalRobos() {
        double total = 0;
        for (Robo robo : robosRegistrados) {
            total += robo.getCosto();
        }
        return total;
    }

    public void mostrarTotalRobos() {
        double totalRobos = calcularCostoTotalRobos();
        System.out.println("Costo total de robos registrados: " + totalRobos);
    }

    private class Robo {
        private int tipo;
        private double costo;

        public Robo(int tipo, double costo) {
            this.tipo = tipo;
            this.costo = costo;
        }

        public double getCosto() {
            return costo;
        }
    }
}


