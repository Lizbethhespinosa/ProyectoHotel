/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Josem
 */
package com.mycompany.hotelfinal2;

import java.util.ArrayList;
import java.util.List;

public class Daños {
    private List<Incidente> incidentes;
    private Lectura lectura = new Lectura(); // Asegúrate de tener esta clase importada y definida correctamente en tu proyecto

    public Daños() {
        this.incidentes = new ArrayList<>();
    }

    public void registrarIncidentes() {
        int tipoIncidente;
        int calcularMas = 1;
        do {
            tipoIncidente = lectura.leeryValidarInt2("Ingrese el tipo de incidente (1 para daño leve, 2 para daño moderado, 3 para daño severo, 4 si no hay daños): ", 1, 4);
            int costoIncidente = 0;
            switch (tipoIncidente) {
                case 1:
                    costoIncidente = 30000; // Daño leve
                    break;
                case 2:
                    costoIncidente = 40000; // Daño moderado
                    break;
                case 3:
                    costoIncidente = 60000; // Daño severo
                    break;
                case 4:
                    System.out.println("No se registraron daños.");
                    break;
                default:
                    break;
            }

            if (tipoIncidente >= 1 && tipoIncidente <= 3) {
                agregarIncidente(tipoIncidente, costoIncidente);
                System.out.println("Daño registrado con éxito.");
            }

            // Verifica si el usuario quiere agregar más incidentes solo si no ha elegido la opción "no hay daños"
            if (tipoIncidente != 4) {
                calcularMas = lectura.leeryValidarInt2("¿Desea registrar otro incidente? (0) para No, (1) para Sí): ", 0, 1);
            } else {
                calcularMas = 0; // No preguntar de nuevo si elige la opción de no hay daños
            }
        } while (calcularMas == 1);

        // Mostrar el costo total de los incidentes registrados
        double costoTotal = calcularCostoTotalIncidentes();
        System.out.println("Costo total de incidentes registrados: " + costoTotal);
    }

    public void agregarIncidente(int tipo, int costo) {
        Incidente incidente = new Incidente(tipo, costo);
        incidentes.add(incidente);
    }

    public double calcularCostoTotalIncidentes() {
        double total = 0;
        for (Incidente incidente : incidentes) {
            total += incidente.getCosto();
        }
        return total;
    }

    private class Incidente {
        private int tipo;
        private double costo;

        public Incidente(int tipo, double costo) {
            this.tipo = tipo;
            this.costo = costo;
        }

        public double getCosto() {
            return costo;
        }
    }
}

