/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;
import java.util.ArrayList;

/**
 *
 * @author Josem
 */
public class HabitacionA implements Habitacion{
    private String numero;
    private final int precioA = 800000;
    private int noches;
    private int costo;
        private boolean ocupada = false;


    
    
    
    ArrayList<String> habitaciones = new ArrayList<>();
    
    Lectura leer = new Lectura();
    Huesped persona = new Huesped();

     public boolean isOcupada() {
        return ocupada;
    }
    
    public int getNoches() {
        return noches;
    }

    public void setNoches(int noches) {
        this.noches = noches;
    }

    /**
     * @return the numero   
     */
    public String getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getPrecioA() {
        return precioA;
    }
    
        public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public boolean estaOcupada() {
    return this.ocupada;
}

    public int getCosto() {
        return costo;
    }

    public void setCosto(int costo) {
        this.costo = costo;
    }
    

    
    @Override
 
    public void datos_habitacion() {
        for (int i = 1; i <= 10; i++) {
    habitaciones.add("a" + i);
}

        for (String habitacion : habitaciones) {
            System.out.println(habitacion);
        }
        this.numero = leer.leerString("Ingrese el numero de habitacion que va a facturar ");
        this.noches= leer.leeryValidarInt("Ingrese el numero de noches");
        this.setOcupada(true);
    }
    
    public int calcularCostoA(){
        this.costo = this.noches * this.precioA;
        System.out.println("El valor a pagar de la habitacion: "+this.numero+ " es de" + this.costo);
        return this.costo;
        
    }
    
}
