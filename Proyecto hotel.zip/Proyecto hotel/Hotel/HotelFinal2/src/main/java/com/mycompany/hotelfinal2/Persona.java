/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.hotelfinal2;

/**
 *
 * @author Josem
 */
public class Persona {
    
    Lectura leer = new Lectura();
    protected int ID;
    protected String nombre;
    protected String celular;
    
    public Persona() {
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    public void darDatos() {
        this.nombre = leer.leerString("Ingrese el nombre: ");
        this.celular = leer.leerString("Ingrese el número de celular: ");
        this.ID = leer.leeryValidarInt("Ingrese el ID: ");
    }
}

