/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotelfinal2;

/**
 *
 * @author Josem
 */
public class FacturarHabitacion {
    private String tipo;
    private int preciofinal;
    
    HabitacionA habitacionA = new HabitacionA();
    HabitacionB habitacionB = new HabitacionB();
    HabitacionD habitacionD = new HabitacionD();
    Lectura leer = new Lectura();
    
    public int getPreciofinal() {
        return preciofinal;
    }

    public void setPreciofinal(int preciofinal) {
        this.preciofinal = preciofinal;
    }
            
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void seleccionarTipo(Persona persona){
        this.tipo = leer.leerString("Ingrese el tipo de habitacion que desea (a_b_d)");

        switch (tipo) {
            case "a":
               
                    habitacionA.datos_habitacion();
                    habitacionA.calcularCostoA();
                    this.preciofinal= habitacionA.getCosto();
               
                break;
            
            case "b":
              
                    habitacionB.datos_habitacion();
                    habitacionB.calcularCostoB();
                    this.preciofinal= habitacionB.getCosto();
             
                break;
            
            case "d":
              
                    habitacionD.datos_habitacion();
                    habitacionD.calcularCostoD();
                    this.preciofinal= habitacionD.getCosto();
              
                break;
            
            default:
                break;
        }
    }
}
